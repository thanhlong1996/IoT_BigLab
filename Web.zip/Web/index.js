const express = require('express'),
  path = require('path'),
  bodyParser = require('body-parser'),
  cors = require('cors');
const socketIO = require('socket.io');

var mqtt = require('mqtt');
const app = express();

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";



// Begin HTTP Server
app.use(bodyParser.json());
app.use(cors());
// Create link to Angular build directory
var distDir = __dirname + "/dist/home";
app.use(express.static(distDir));

const deviceRoute = require('./routes/deviceroute');
const userRoute = require('./routes/userroute');
const port = process.env.PORT || 4000;
app.use('/device', deviceRoute);
app.use('/user', userRoute);

// Create View Server
var http = require('http').Server(app);
var io = socketIO(http);

// create an mqtt client object and connect to the mqtt broker
var client = mqtt.connect('tcp://mqtt.thingspeak.com/', {
  port: 1883,
  clientId: 'mqttjs_' + Math.random().toString(16).substr(2, 8),
  username: 'ntlongiot2018',
  password: 'N3S51HU9824KW0D1'
});

client.on('connect', function () {
    console.log('Connecting to mqtt');
    client.subscribe('channels/630223/subscribe/json/L681BGTSS07Z3EUK');
    // listen to messages coming from the mqtt broker
    client.on('message', function (topic, payload, packet) {
      console.log(topic + ' = ' + payload);
      console.log(packet);
     
      var result_ob = JSON.parse(payload.toString());

      console.log(result_ob);


      MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("thingspeak");
        var myobj = { sen_id: result_ob.field1, 
                        type: result_ob.field2, 
                        data_reading: result_ob.field3, 
                        date: result_ob.field4, 
                        gateway_id: result_ob.field5 
                    };
        dbo.collection("device").insertOne(myobj, function(err, res) {
            if (err) throw err;
            console.log("1 document inserted");
            db.close();
        });
      }); 


            
      io.emit('smarthome', { sen_id: result_ob.field1, 
        type: result_ob.field2, 
        data_reading: result_ob.field3, 
        date: result_ob.field4, 
        gateway_id: result_ob.field5 } );
    

      console.log("DONE SOCKET");
    });
});

// Create socket
let numberOfOnlineUsers = 0;
io.on('connection', (socket) => {
  numberOfOnlineUsers++;
  io.emit('numberOfOnlineUsers', numberOfOnlineUsers);

  console.log('New user connected');

  socket.on('disconnect', () => {
    numberOfOnlineUsers--;
    io.emit('numberOfOnlineUsers', numberOfOnlineUsers);
    console.log('User disconnected');
  });
});





//Start running
http.listen(port, () => {
    console.log('Server started on port ' + port);
});