
const express = require('express');
const app = express();
const deviceRoute = express.Router();
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

deviceRoute.route('/').get(function (req, res) {
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("thingspeak");
        dbo.collection("device").find({}).toArray(function(err, result) {
          if (err) throw err;
          console.log(result);
          res.json(result);
          db.close();
        });
    }); 

});

deviceRoute.route('/add').post(function (req, res) {
    console.log(req.body);
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("thingspeak");
        var result_ob = req.body;
        var myobj = { sen_id: result_ob.sen_id, 
            type: result_ob.type, 
            data_reading: result_ob.data_reading, 
            date: result_ob.date, 
            gateway_id: result_ob.gateway_id 
        };
        dbo.collection("device").insertOne(myobj, function(err, res) {
            if (err) throw err;
            console.log("1 document inserted");
            db.close();
        });
    }); 
    res.status(200).send("Success");

});

deviceRoute.route('/query/:id').get(function (req, res) {
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("thingspeak");
        var query = { sen_id: req.params.idd1 };
        dbo.collection("device").find(query).toArray(function(err, result) {
          if (err) throw err;
          console.log(result);
          res.json(result);
          db.close();
        });
    }); 
    res.status(200).send("Success");

});
  
//  Defined update route
deviceRoute.route('/update/:id').post(function (req, res) {

});
  
// Defined delete | remove | destroy route
deviceRoute.route('/delete/:id').get(function (req, res) {
    console.log(req);
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("thingspeak");
        var myquery = { sen_id: req.params.id };
        dbo.collection("device").deleteMany(myquery, function(err, obj) {
            if (err) throw err;
            console.log("1 document deleted");
            db.close();
        });
    }); 
    res.status(200).send("Success");
});
  

module.exports = deviceRoute;