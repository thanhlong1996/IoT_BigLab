
const express = require('express');
const app = express();
const userroute = express.Router();
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

userroute.route('/').get(function (req, res) {
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("thingspeak");
        dbo.collection("user").find({}).toArray(function(err, result) {
          if (err) throw err;
          console.log(result);
          res.json(result);
          db.close();
        });
    }); 

});

userroute.route('/add').post(function (req, res) {
    console.log(req.body);
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("thingspeak");
        var result_ob = req.body;
        var myobj = { username: result_ob.username, 
            password: result_ob.password, 
            date: result_ob.date 
        };
        dbo.collection("user").insertOne(myobj, function(err, res) {
            if (err) throw err;
            console.log("1 document inserted");
            db.close();
        });
    }); 
    res.status(200).send("Success");

});

userroute.route('/query/:id').get(function (req, res) {
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("thingspeak");
        var query = { username: req.params.idd1 };
        dbo.collection("user").find(query).toArray(function(err, result) {
          if (err) throw err;
          console.log(result);
          res.json(result);
          db.close();
        });
    }); 
    res.status(200).send("Success");

});
  
//  Defined update route
userroute.route('/update/:id').post(function (req, res) {

});
  
// Defined delete | remove | destroy route
userroute.route('/delete/:id').get(function (req, res) {
    console.log(req);
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("thingspeak");
        var myquery = { username: req.params.id };
        dbo.collection("user").deleteMany(myquery, function(err, obj) {
            if (err) throw err;
            console.log("1 document deleted");
            db.close();
        });
    }); 
    res.status(200).send("Success");
});
  

module.exports = userroute;